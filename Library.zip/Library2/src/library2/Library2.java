/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



/**
 *
 * @author Saleh
 */
public class Library2 {

    private final String url = "jdbc:postgresql://localhost/Database4";
    private final String user = "postgres";
    private final String password = "*********";


    public Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the PostgreSQL server successfully.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return conn;
    }
    public void getbook(){
        Connection conn = null;
        Statement stat = null;
        ResultSet rs = null;
        Library2 obj = new Library2();
        conn = obj.connect();
        int x = 950;
        try {
            String qu = "select * from book where book_id > 10006" ;
            stat = conn.createStatement();
            rs = stat.executeQuery(qu);
            while(rs.next()){
                System.out.println(rs.getInt("book_id") + " "+ rs.getString("author")+ " " + rs.getString(3));
            }

        } catch (Exception e) {
            System.out.println("no");
        }
    }

    public static void main(String[] args) {
        Library2 app = new Library2();
        app.getbook();

    }

}
